from django.contrib import admin
from ship.models import FW, MDO, Ship

admin.site.register(FW)
admin.site.register(MDO)
admin.site.register(Ship)

# Register your models here.
