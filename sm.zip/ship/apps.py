from django.apps import AppConfig


class ShipConfig(AppConfig):
    name = 'ship'
